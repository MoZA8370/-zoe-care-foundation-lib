# Zoe Care Foundation-Lib Website

A responsive static website for Zoe Care Foundation-Lib.

## Files
- index.html — main website
- styles.css — design and responsive layout
- script.js — mobile navigation and current year

## Publish for free
Upload these three files to a GitHub repository and enable GitHub Pages, or upload the folder to Cloudflare Pages.

## Before launch
Replace the ZC text mark with the organization's official logo if available, add approved photos, and add official social-media links. The contact form currently opens the visitor's email application; a form service can be connected later.
